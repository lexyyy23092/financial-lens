from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go


def plot_missing_values(missing_df: pd.DataFrame):
    chart_df = missing_df[missing_df["missing_count"] > 0].copy()
    if chart_df.empty:
        return None
    return px.bar(chart_df, x="column", y="missing_%", title="Missing Values by Column")


def plot_distribution(df: pd.DataFrame, column: str):
    return px.histogram(df, x=column, marginal="box", title=f"Distribution of {column}")


def plot_boxplot(df: pd.DataFrame, column: str):
    return px.box(df, y=column, title=f"Boxplot of {column}")


def plot_correlation_heatmap(corr: pd.DataFrame, title: str = "Correlation Matrix"):
    fig = go.Figure(
        data=go.Heatmap(
            z=corr.values,
            x=corr.columns,
            y=corr.index,
            colorscale="RdBu",
            zmin=-1,
            zmax=1,
            colorbar=dict(title="Correlation"),
            hovertemplate="%{y} vs %{x}<br>Correlation: %{z:.3f}<extra></extra>",
        )
    )
    fig.update_layout(title=title, height=620)
    return fig


def plot_time_series(ts: pd.DataFrame, x_col: str, y_col: str, title: str):
    return px.line(ts, x=x_col, y=y_col, title=title)


def plot_actual_predicted(test_df: pd.DataFrame, title: str = "Actual vs Predicted"):
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=test_df["ds"], y=test_df["actual"], name="Actual", mode="lines"))
    fig.add_trace(go.Scatter(x=test_df["ds"], y=test_df["predicted"], name="Predicted", mode="lines"))
    fig.update_layout(title=title, xaxis_title="Date", yaxis_title="Value", height=520)
    return fig


def plot_forecast(history_df: pd.DataFrame, future_df: pd.DataFrame, title: str = "Forecast"):
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=history_df["ds"], y=history_df["y"], name="Historical", mode="lines"))
    fig.add_trace(go.Scatter(x=future_df["ds"], y=future_df["forecast"], name="Forecast", mode="lines"))

    if {"lower", "upper"}.issubset(future_df.columns):
        fig.add_trace(
            go.Scatter(
                x=list(future_df["ds"]) + list(future_df["ds"])[::-1],
                y=list(future_df["upper"]) + list(future_df["lower"])[::-1],
                fill="toself",
                name="Forecast interval",
                line=dict(width=0),
                opacity=0.25,
            )
        )

    fig.update_layout(title=title, xaxis_title="Date", yaxis_title="Value", height=560)
    return fig


def _reset_with_date_column(df: pd.DataFrame) -> tuple[pd.DataFrame, str]:
    date_col = df.index.name if df.index.name else "Date"
    out = df.copy()
    out.index.name = date_col
    return out.reset_index(), date_col


def plot_prices(price_df: pd.DataFrame, title: str = "Price History"):
    reset_df, date_col = _reset_with_date_column(price_df)
    tidy = reset_df.melt(id_vars=date_col, var_name="Asset", value_name="Price")
    return px.line(tidy, x=date_col, y="Price", color="Asset", title=title)


def plot_returns(returns_df: pd.DataFrame, title: str = "Return History"):
    reset_df, date_col = _reset_with_date_column(returns_df)
    tidy = reset_df.melt(id_vars=date_col, var_name="Asset", value_name="Return")
    return px.line(tidy, x=date_col, y="Return", color="Asset", title=title)
