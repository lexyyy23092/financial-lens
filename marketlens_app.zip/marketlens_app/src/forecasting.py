from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd

from .utils import calculate_metrics


@dataclass
class ForecastResult:
    model_name: str
    test_predictions: pd.DataFrame
    future_forecast: pd.DataFrame
    metrics: dict[str, float]
    notes: str


def split_train_test(ts_df: pd.DataFrame, test_size: float = 0.2) -> tuple[pd.DataFrame, pd.DataFrame]:
    if not 0.05 <= test_size <= 0.5:
        raise ValueError("Test size should be between 0.05 and 0.50.")
    split_index = int(len(ts_df) * (1 - test_size))
    if split_index < 20 or len(ts_df) - split_index < 5:
        raise ValueError("Not enough observations for the selected train/test split.")
    return ts_df.iloc[:split_index].copy(), ts_df.iloc[split_index:].copy()


def future_dates(last_date: pd.Timestamp, periods: int, freq: str) -> pd.DatetimeIndex:
    return pd.date_range(start=last_date, periods=periods + 1, freq=freq)[1:]


def naive_forecast(ts_df: pd.DataFrame, horizon: int, freq: str, test_size: float) -> ForecastResult:
    train, test = split_train_test(ts_df, test_size)
    history = list(train["y"].values)
    preds = []
    for actual in test["y"].values:
        preds.append(history[-1])
        history.append(actual)

    test_pred = pd.DataFrame({"ds": test["ds"].values, "actual": test["y"].values, "predicted": preds})
    future_idx = future_dates(pd.to_datetime(ts_df["ds"].iloc[-1]), horizon, freq)
    future_df = pd.DataFrame({"ds": future_idx, "forecast": [ts_df["y"].iloc[-1]] * horizon})
    metrics = calculate_metrics(test_pred["actual"], test_pred["predicted"])
    return ForecastResult("Naive", test_pred, future_df, metrics, "Baseline model: predicts the next value as the most recent observed value.")


def moving_average_forecast(ts_df: pd.DataFrame, horizon: int, freq: str, test_size: float, window: int = 7) -> ForecastResult:
    train, test = split_train_test(ts_df, test_size)
    if len(train) < window:
        raise ValueError(f"Need at least {window} training observations for moving average.")

    history = list(train["y"].values)
    preds = []
    for actual in test["y"].values:
        pred = float(np.mean(history[-window:]))
        preds.append(pred)
        history.append(actual)

    future_history = list(ts_df["y"].values)
    future_preds = []
    for _ in range(horizon):
        pred = float(np.mean(future_history[-window:]))
        future_preds.append(pred)
        future_history.append(pred)

    test_pred = pd.DataFrame({"ds": test["ds"].values, "actual": test["y"].values, "predicted": preds})
    future_df = pd.DataFrame({"ds": future_dates(pd.to_datetime(ts_df["ds"].iloc[-1]), horizon, freq), "forecast": future_preds})
    metrics = calculate_metrics(test_pred["actual"], test_pred["predicted"])
    return ForecastResult(f"Moving Average ({window})", test_pred, future_df, metrics, "Rolling average model: smooths recent values and recursively projects forward.")


def arima_forecast(ts_df: pd.DataFrame, horizon: int, freq: str, test_size: float, order: tuple[int, int, int] = (5, 1, 0)) -> ForecastResult:
    try:
        from statsmodels.tsa.arima.model import ARIMA
    except ImportError as exc:
        raise ImportError("statsmodels is required for ARIMA. Install it with: pip install statsmodels") from exc

    train, test = split_train_test(ts_df, test_size)
    model = ARIMA(train["y"].astype(float), order=order)
    fitted = model.fit()
    forecast_values = fitted.forecast(steps=len(test) + horizon)
    test_values = np.asarray(forecast_values[: len(test)], dtype=float)
    future_values = np.asarray(forecast_values[len(test) :], dtype=float)

    test_pred = pd.DataFrame({"ds": test["ds"].values, "actual": test["y"].values, "predicted": test_values})
    future_df = pd.DataFrame({"ds": future_dates(pd.to_datetime(ts_df["ds"].iloc[-1]), horizon, freq), "forecast": future_values})
    metrics = calculate_metrics(test_pred["actual"], test_pred["predicted"])
    return ForecastResult(f"ARIMA{order}", test_pred, future_df, metrics, "Classic statistical time-series model. Default order is configurable in code.")


def prophet_forecast(ts_df: pd.DataFrame, horizon: int, freq: str, test_size: float) -> ForecastResult:
    try:
        from prophet import Prophet
    except ImportError as exc:
        raise ImportError("Prophet is required for this model. Install it with: pip install prophet") from exc

    train, test = split_train_test(ts_df, test_size)
    prophet_train = train[["ds", "y"]].copy()
    model = Prophet(daily_seasonality=False, weekly_seasonality=True, yearly_seasonality=True)
    model.fit(prophet_train)

    future = model.make_future_dataframe(periods=len(test) + horizon, freq=freq)
    forecast = model.predict(future)
    holdout_forecast = forecast.tail(len(test) + horizon).copy()

    test_part = holdout_forecast.head(len(test))
    future_part = holdout_forecast.tail(horizon)

    test_pred = pd.DataFrame(
        {
            "ds": test["ds"].values,
            "actual": test["y"].values,
            "predicted": test_part["yhat"].values,
        }
    )
    future_df = pd.DataFrame(
        {
            "ds": future_part["ds"].values,
            "forecast": future_part["yhat"].values,
            "lower": future_part["yhat_lower"].values,
            "upper": future_part["yhat_upper"].values,
        }
    )
    metrics = calculate_metrics(test_pred["actual"], test_pred["predicted"])
    return ForecastResult("Prophet", test_pred, future_df, metrics, "Trend/seasonality model with forecast intervals.")


def _make_lag_features(series: pd.Series, n_lags: int) -> pd.DataFrame:
    df = pd.DataFrame({"y": series.values})
    for lag in range(1, n_lags + 1):
        df[f"lag_{lag}"] = df["y"].shift(lag)
    df["rolling_mean_7"] = df["y"].shift(1).rolling(7).mean()
    df["rolling_std_7"] = df["y"].shift(1).rolling(7).std()
    df["rolling_mean_14"] = df["y"].shift(1).rolling(14).mean()
    return df.dropna()


def xgboost_forecast(ts_df: pd.DataFrame, horizon: int, freq: str, test_size: float, n_lags: int = 14) -> ForecastResult:
    try:
        from xgboost import XGBRegressor
    except ImportError as exc:
        raise ImportError("XGBoost is required for this model. Install it with: pip install xgboost") from exc

    train, test = split_train_test(ts_df, test_size)
    full_features = _make_lag_features(ts_df["y"], n_lags=n_lags)
    feature_cols = [c for c in full_features.columns if c != "y"]
    feature_dates = ts_df["ds"].iloc[len(ts_df) - len(full_features) :].reset_index(drop=True)
    full_features = full_features.reset_index(drop=True)
    full_features["ds"] = feature_dates

    train_cutoff = train["ds"].iloc[-1]
    train_features = full_features[full_features["ds"] <= train_cutoff]
    test_features = full_features[full_features["ds"] > train_cutoff]

    if train_features.empty or test_features.empty:
        raise ValueError("Not enough lagged observations for XGBoost. Try a longer dataset or smaller lag count.")

    model = XGBRegressor(
        n_estimators=300,
        learning_rate=0.03,
        max_depth=3,
        subsample=0.9,
        colsample_bytree=0.9,
        objective="reg:squarederror",
        random_state=42,
    )
    model.fit(train_features[feature_cols], train_features["y"])
    preds = model.predict(test_features[feature_cols])

    test_pred = pd.DataFrame({"ds": test_features["ds"].values, "actual": test_features["y"].values, "predicted": preds})

    history = list(ts_df["y"].astype(float).values)
    future_preds: list[float] = []
    for _ in range(horizon):
        row = {}
        for lag in range(1, n_lags + 1):
            row[f"lag_{lag}"] = history[-lag]
        row["rolling_mean_7"] = float(np.mean(history[-7:]))
        row["rolling_std_7"] = float(np.std(history[-7:], ddof=1)) if len(history[-7:]) > 1 else 0.0
        row["rolling_mean_14"] = float(np.mean(history[-14:]))
        pred = float(model.predict(pd.DataFrame([row])[feature_cols])[0])
        future_preds.append(pred)
        history.append(pred)

    future_df = pd.DataFrame({"ds": future_dates(pd.to_datetime(ts_df["ds"].iloc[-1]), horizon, freq), "forecast": future_preds})
    metrics = calculate_metrics(test_pred["actual"], test_pred["predicted"])
    return ForecastResult("XGBoost", test_pred, future_df, metrics, "Machine-learning model using lag and rolling-window features.")


def run_forecast(
    model_name: str,
    ts_df: pd.DataFrame,
    horizon: int,
    freq: str,
    test_size: float = 0.2,
    moving_average_window: int = 7,
) -> ForecastResult:
    ts_df = ts_df[["ds", "y"]].copy()
    ts_df["ds"] = pd.to_datetime(ts_df["ds"])
    ts_df["y"] = pd.to_numeric(ts_df["y"], errors="coerce")
    ts_df = ts_df.dropna().sort_values("ds").reset_index(drop=True)

    if horizon < 1:
        raise ValueError("Forecast horizon must be at least 1.")
    if len(ts_df) < 30:
        raise ValueError("Forecasting needs at least 30 observations.")

    normalized = model_name.lower()
    if normalized.startswith("naive"):
        return naive_forecast(ts_df, horizon, freq, test_size)
    if normalized.startswith("moving"):
        return moving_average_forecast(ts_df, horizon, freq, test_size, moving_average_window)
    if normalized.startswith("arima"):
        return arima_forecast(ts_df, horizon, freq, test_size)
    if normalized.startswith("prophet"):
        return prophet_forecast(ts_df, horizon, freq, test_size)
    if normalized.startswith("xgboost"):
        return xgboost_forecast(ts_df, horizon, freq, test_size)

    raise ValueError(f"Unknown model: {model_name}")
