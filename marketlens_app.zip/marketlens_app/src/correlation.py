from __future__ import annotations

import pandas as pd

from .utils import safe_pct_change


def prepare_returns(price_df: pd.DataFrame, return_frequency: str = "Daily") -> pd.DataFrame:
    clean_prices = price_df.sort_index().ffill().dropna(how="all")

    if return_frequency == "Weekly":
        clean_prices = clean_prices.resample("W-FRI").last()
    elif return_frequency == "Monthly":
        clean_prices = clean_prices.resample("M").last()

    returns = safe_pct_change(clean_prices)
    returns = returns.dropna(axis=1, how="all").dropna(how="any")
    return returns


def correlation_matrix_from_prices(price_df: pd.DataFrame, return_frequency: str = "Daily") -> tuple[pd.DataFrame, pd.DataFrame]:
    returns = prepare_returns(price_df, return_frequency=return_frequency)
    if returns.empty or returns.shape[1] < 2:
        raise ValueError("Not enough aligned return data to calculate correlations.")
    return returns.corr(), returns


def strongest_correlations(corr: pd.DataFrame, top_n: int = 5) -> pd.DataFrame:
    rows = []
    cols = list(corr.columns)
    for i, a in enumerate(cols):
        for b in cols[i + 1 :]:
            value = corr.loc[a, b]
            rows.append({"Asset 1": a, "Asset 2": b, "Correlation": value})
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    out["Abs Correlation"] = out["Correlation"].abs()
    return out.sort_values("Abs Correlation", ascending=False).head(top_n).drop(columns=["Abs Correlation"])
