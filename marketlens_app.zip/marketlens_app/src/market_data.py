from __future__ import annotations

import pandas as pd
import streamlit as st
import yfinance as yf


ASSET_UNIVERSE: dict[str, str] = {
    "NIFTY 50": "^NSEI",
    "SENSEX": "^BSESN",
    "S&P 500": "^GSPC",
    "NASDAQ Composite": "^IXIC",
    "Dow Jones Industrial Average": "^DJI",
    "Gold Futures": "GC=F",
    "Silver Futures": "SI=F",
    "Crude Oil WTI": "CL=F",
    "USD/INR": "INR=X",
    "Bitcoin": "BTC-USD",
    "FTSE 100": "^FTSE",
    "DAX": "^GDAXI",
    "Nikkei 225": "^N225",
    "Hang Seng": "^HSI",
}

DEFAULT_CORRELATION_ASSETS = [
    "NIFTY 50",
    "SENSEX",
    "S&P 500",
    "NASDAQ Composite",
    "Dow Jones Industrial Average",
    "Gold Futures",
    "Silver Futures",
]


@st.cache_data(show_spinner=False, ttl=60 * 60)
def download_single_asset(symbol: str, start: str, end: str) -> pd.DataFrame:
    data = yf.download(symbol, start=start, end=end, progress=False, auto_adjust=False, threads=False)
    if data.empty:
        raise ValueError(f"No data returned for {symbol}.")

    if isinstance(data.columns, pd.MultiIndex):
        data.columns = data.columns.get_level_values(0)

    data = data.reset_index()
    if "Adj Close" in data.columns:
        data["Price"] = data["Adj Close"]
    elif "Close" in data.columns:
        data["Price"] = data["Close"]
    else:
        raise ValueError(f"Downloaded data for {symbol} does not include Close/Adj Close.")

    cols = [col for col in ["Date", "Open", "High", "Low", "Close", "Adj Close", "Volume", "Price"] if col in data.columns]
    return data[cols].dropna(subset=["Date", "Price"])


@st.cache_data(show_spinner=False, ttl=60 * 60)
def download_price_matrix(asset_map: dict[str, str], start: str, end: str) -> pd.DataFrame:
    price_series = []
    errors: list[str] = []

    for asset_name, symbol in asset_map.items():
        try:
            df = download_single_asset(symbol, start, end)
            s = df.set_index("Date")["Price"].rename(asset_name)
            price_series.append(s)
        except Exception as exc:  # Streamlit app should keep running even if one ticker fails.
            errors.append(f"{asset_name} ({symbol}): {exc}")

    if not price_series:
        raise ValueError("No asset data could be downloaded. Try a different date range or fewer assets.")

    matrix = pd.concat(price_series, axis=1).sort_index()
    matrix = matrix.dropna(how="all")
    matrix.attrs["download_errors"] = errors
    return matrix
