from __future__ import annotations

import numpy as np
import pandas as pd


def dataset_overview(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for col in df.columns:
        rows.append(
            {
                "column": col,
                "dtype": str(df[col].dtype),
                "non_null": int(df[col].notna().sum()),
                "missing": int(df[col].isna().sum()),
                "missing_%": round(float(df[col].isna().mean() * 100), 2),
                "unique": int(df[col].nunique(dropna=True)),
            }
        )
    return pd.DataFrame(rows)


def missing_values_report(df: pd.DataFrame) -> pd.DataFrame:
    report = pd.DataFrame(
        {
            "column": df.columns,
            "missing_count": df.isna().sum().values,
            "missing_%": (df.isna().mean().values * 100).round(2),
        }
    )
    return report.sort_values("missing_count", ascending=False)


def numeric_summary(df: pd.DataFrame) -> pd.DataFrame:
    numeric_df = df.select_dtypes(include=[np.number])
    if numeric_df.empty:
        return pd.DataFrame()
    summary = numeric_df.describe().T
    summary["median"] = numeric_df.median(numeric_only=True)
    summary["skew"] = numeric_df.skew(numeric_only=True)
    summary["kurtosis"] = numeric_df.kurtosis(numeric_only=True)
    return summary.reset_index().rename(columns={"index": "column"})


def categorical_summary(df: pd.DataFrame, max_columns: int = 8) -> pd.DataFrame:
    rows = []
    cat_cols = df.select_dtypes(include=["object", "category", "bool"]).columns[:max_columns]
    for col in cat_cols:
        top_value = df[col].mode(dropna=True)
        rows.append(
            {
                "column": col,
                "unique": int(df[col].nunique(dropna=True)),
                "top_value": top_value.iloc[0] if not top_value.empty else None,
                "top_value_count": int(df[col].value_counts(dropna=True).iloc[0]) if not df[col].value_counts(dropna=True).empty else 0,
            }
        )
    return pd.DataFrame(rows)


def duplicate_count(df: pd.DataFrame) -> int:
    return int(df.duplicated().sum())


def iqr_outlier_report(df: pd.DataFrame) -> pd.DataFrame:
    numeric_df = df.select_dtypes(include=[np.number])
    rows = []
    for col in numeric_df.columns:
        q1 = numeric_df[col].quantile(0.25)
        q3 = numeric_df[col].quantile(0.75)
        iqr = q3 - q1
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr
        count = int(((numeric_df[col] < lower) | (numeric_df[col] > upper)).sum())
        rows.append({"column": col, "outlier_count": count, "outlier_%": round(count / len(df) * 100, 2)})
    return pd.DataFrame(rows).sort_values("outlier_count", ascending=False)
