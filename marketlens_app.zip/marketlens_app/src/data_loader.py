from __future__ import annotations

from io import BytesIO
from typing import Optional

import numpy as np
import pandas as pd

from .utils import clean_column_names


def load_uploaded_file(uploaded_file) -> pd.DataFrame:
    """Read a CSV/XLSX file uploaded through Streamlit."""
    if uploaded_file is None:
        raise ValueError("No file uploaded.")

    filename = uploaded_file.name.lower()
    if filename.endswith(".csv"):
        df = pd.read_csv(uploaded_file)
    elif filename.endswith((".xlsx", ".xls")):
        df = pd.read_excel(uploaded_file)
    else:
        raise ValueError("Unsupported file type. Please upload a CSV or Excel file.")

    if df.empty:
        raise ValueError("The uploaded file is empty.")

    return clean_column_names(df)


def infer_date_columns(df: pd.DataFrame, min_success_rate: float = 0.70) -> list[str]:
    candidates: list[str] = []
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            candidates.append(col)
            continue

        if pd.api.types.is_object_dtype(df[col]) or pd.api.types.is_string_dtype(df[col]):
            parsed = pd.to_datetime(df[col], errors="coerce", infer_datetime_format=True)
            success_rate = parsed.notna().mean()
            if success_rate >= min_success_rate:
                candidates.append(col)
    return candidates


def get_numeric_columns(df: pd.DataFrame) -> list[str]:
    return list(df.select_dtypes(include=[np.number]).columns)


def get_categorical_columns(df: pd.DataFrame, max_unique_ratio: float = 0.5) -> list[str]:
    categorical: list[str] = []
    for col in df.columns:
        if pd.api.types.is_object_dtype(df[col]) or pd.api.types.is_categorical_dtype(df[col]):
            categorical.append(col)
        elif df[col].nunique(dropna=True) <= max(20, int(len(df) * max_unique_ratio)) and not pd.api.types.is_numeric_dtype(df[col]):
            categorical.append(col)
    return categorical


def prepare_time_series(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    freq: str = "D",
    aggregation: str = "mean",
) -> pd.DataFrame:
    """Return a clean two-column time-series dataframe: ds, y."""
    if date_col not in df.columns:
        raise ValueError(f"Date column '{date_col}' not found.")
    if target_col not in df.columns:
        raise ValueError(f"Target column '{target_col}' not found.")

    ts = df[[date_col, target_col]].copy()
    ts[date_col] = pd.to_datetime(ts[date_col], errors="coerce")
    ts[target_col] = pd.to_numeric(ts[target_col], errors="coerce")
    ts = ts.dropna(subset=[date_col, target_col])

    if ts.empty:
        raise ValueError("No valid date/target rows remain after cleaning.")

    ts = ts.sort_values(date_col)
    ts = ts.rename(columns={date_col: "ds", target_col: "y"})
    ts = ts.groupby("ds", as_index=False)["y"].mean()
    ts = ts.set_index("ds")

    if aggregation == "sum":
        ts = ts.resample(freq).sum()
    elif aggregation == "median":
        ts = ts.resample(freq).median()
    elif aggregation == "last":
        ts = ts.resample(freq).last()
    else:
        ts = ts.resample(freq).mean()

    ts["y"] = ts["y"].interpolate(method="time").ffill().bfill()
    ts = ts.reset_index()

    if len(ts) < 30:
        raise ValueError("The prepared time series has fewer than 30 observations. Forecasting needs more history.")

    return ts


def dataframe_to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")
