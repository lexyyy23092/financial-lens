from __future__ import annotations

import math
from typing import Iterable

import numpy as np
import pandas as pd


def infer_frequency_label(freq_code: str) -> str:
    mapping = {
        "D": "Daily",
        "B": "Business daily",
        "W": "Weekly",
        "M": "Monthly",
        "MS": "Monthly",
        "Q": "Quarterly",
        "Y": "Yearly",
        "A": "Yearly",
    }
    return mapping.get(freq_code, freq_code)


def calculate_metrics(actual: Iterable[float], predicted: Iterable[float]) -> dict[str, float]:
    actual_arr = np.asarray(list(actual), dtype=float)
    pred_arr = np.asarray(list(predicted), dtype=float)

    mask = np.isfinite(actual_arr) & np.isfinite(pred_arr)
    actual_arr = actual_arr[mask]
    pred_arr = pred_arr[mask]

    if len(actual_arr) == 0:
        return {"MAE": np.nan, "RMSE": np.nan, "MAPE": np.nan}

    mae = np.mean(np.abs(actual_arr - pred_arr))
    rmse = math.sqrt(np.mean((actual_arr - pred_arr) ** 2))

    non_zero_mask = actual_arr != 0
    if non_zero_mask.any():
        mape = np.mean(np.abs((actual_arr[non_zero_mask] - pred_arr[non_zero_mask]) / actual_arr[non_zero_mask])) * 100
    else:
        mape = np.nan

    return {"MAE": float(mae), "RMSE": float(rmse), "MAPE": float(mape) if np.isfinite(mape) else np.nan}


def format_metric(value: float, decimals: int = 3) -> str:
    if value is None or not np.isfinite(value):
        return "N/A"
    return f"{value:,.{decimals}f}"


def safe_pct_change(df: pd.DataFrame) -> pd.DataFrame:
    returns = df.pct_change(fill_method=None)
    returns = returns.replace([np.inf, -np.inf], np.nan).dropna(how="all")
    return returns


def clean_column_names(df: pd.DataFrame) -> pd.DataFrame:
    cleaned = df.copy()
    cleaned.columns = [str(col).strip().replace("\n", " ") for col in cleaned.columns]
    return cleaned
