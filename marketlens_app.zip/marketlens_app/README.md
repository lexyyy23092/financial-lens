# MarketLens: EDA, Forecasting & Correlation Dashboard

MarketLens is a Streamlit web application for:

1. Automated exploratory data analysis for user-uploaded CSV/XLSX datasets.
2. Time-series forecasting on either uploaded data or predefined market assets.
3. Correlation analysis across major indices, commodities, currencies, and crypto.

> This app is designed for analytics education and project demonstration. Market forecasts are not investment advice.

## Features

### 1. Upload & EDA

Upload a CSV or Excel file and automatically view:

- Dataset preview
- Shape, missing values, and duplicate rows
- Column data types
- Numeric summary statistics
- Categorical summaries
- Missing-value chart
- Distribution explorer
- IQR-based outlier report
- Numeric correlation heatmap
- Time-series preview when a date column exists

### 2. Forecasting

Forecast from either:

- An uploaded dataset, where you choose the date and target columns
- A predefined market asset downloaded from Yahoo Finance

Included models:

- Naive baseline
- Moving average
- ARIMA
- Prophet
- XGBoost

Outputs:

- Historical time-series chart
- Actual vs predicted chart on test data
- MAE, RMSE, and MAPE metrics
- Future forecast chart
- Downloadable forecast CSV

### 3. Correlation Matrix

Default correlation universe:

- NIFTY 50
- SENSEX
- S&P 500
- NASDAQ Composite
- Dow Jones Industrial Average
- Gold Futures
- Silver Futures

Optional assets include crude oil, USD/INR, Bitcoin, FTSE 100, DAX, Nikkei 225, and Hang Seng.

Correlations are calculated on percentage returns, not raw prices.

## Project Structure

```text
marketlens_app/
  app.py
  requirements.txt
  README.md
  sample_data/
    sample_sales_data.csv
  src/
    __init__.py
    charts.py
    correlation.py
    data_loader.py
    eda.py
    forecasting.py
    market_data.py
    utils.py
```

## Installation

Create and activate a virtual environment:

```bash
python -m venv .venv

# Windows
.venv\Scripts\activate

# macOS/Linux
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Run the app:

```bash
streamlit run app.py
```

## Notes on dependencies

`Prophet` and `XGBoost` are included in `requirements.txt`. If installation is slow on your system, you can still run the app with Naive, Moving Average, and ARIMA by temporarily removing `prophet` and/or `xgboost` from `requirements.txt`. The app shows a clear message if an optional model library is unavailable.

## Data Source

Predefined market assets are downloaded using `yfinance`, which retrieves Yahoo Finance market data.

## Suggested Demo Flow

1. Open **Upload & EDA**.
2. Enable **Use sample dataset** or upload your own CSV/XLSX file.
3. Explore missing values, summaries, distributions, and correlations.
4. Open **Forecasting**.
5. Choose uploaded data or a predefined market asset.
6. Select a model and run the forecast.
7. Open **Correlation Matrix**.
8. Select assets and generate a return-correlation heatmap.

## Limitations

- Market data availability depends on Yahoo Finance.
- Forecasting models are simplified for project demonstration.
- Correlation does not imply causation.
- Financial forecasting is uncertain and should not be treated as trading guidance.
